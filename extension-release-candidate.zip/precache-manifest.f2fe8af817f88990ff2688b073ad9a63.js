self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "b4233db96584f1f2aa1e",
    "url": "/static/js/main.b4233db9.chunk.js"
  },
  {
    "revision": "bbf3c464749d514cd7ac",
    "url": "/static/js/2.bbf3c464.chunk.js"
  },
  {
    "revision": "b4233db96584f1f2aa1e",
    "url": "/static/css/main.9cc43f45.chunk.css"
  },
  {
    "revision": "bbf3c464749d514cd7ac",
    "url": "/static/css/2.917428e4.chunk.css"
  },
  {
    "revision": "d557cd92590bf26c781bd17c422de1df",
    "url": "/index.html"
  }
];